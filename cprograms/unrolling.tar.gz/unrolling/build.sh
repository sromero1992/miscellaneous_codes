gcc -o test_unroll_1 unroll_1.c -std=c99
gcc -o test_unroll_2 unroll_2.c -std=c99
gcc -o test_unroll_3 unroll_3.c -std=c99
gcc -o test_unroll_4 unroll_4.c -std=c99
gcc -o test_unroll_5 unroll_5.c -std=c99
gcc -o test_unroll_6 unroll_6.c -std=c99
