gcc -o calc calcPi.c -std=c99 -fopenmp -lm

for np in 1 2 4 8 16
do
  export OMP_NUM_THREADS=${np}
  echo "${np}-processor result: "
  ./calc
done
