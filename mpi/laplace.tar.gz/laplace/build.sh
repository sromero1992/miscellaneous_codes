mpicc -o laplace laplace.c -std=c99
