#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main( int argc, char** argv ) {
  int procID, nproc, root, source, target, tag;
  int k, ncolors, pcolor;
  int *colorArray;
  char color[20];
  MPI_Status status;

  // Set the rank 0 process as the root process
  root = 0;

  // Generate three colors for color array, where white = 0, red = 1, and green = 2
  ncolors = 3;
  colorArray = (int*) malloc( sizeof(int) * ncolors );

  // Initialize MPI
  MPI_Init( &argc, &argv );

  // Get process rank
  MPI_Comm_rank( MPI_COMM_WORLD, &procID );

  // Get total number of processes specified at start of run
  MPI_Comm_size( MPI_COMM_WORLD, &nproc );

  if ( procID == root )
    for ( k = 0; k < ncolors; k++ )
      colorArray[k] = k;

  // Broadcast the array of colors to all processes
  MPI_Bcast( colorArray, ncolors, MPI_INT, root, MPI_COMM_WORLD );

  // Color each process 'green' (color = 2)
  pcolor = colorArray[2];

  // Have each process send its color to the root process
  tag = pcolor;
  target = 0;

  // Part one

  if ( procID != root )
    MPI_Send( &pcolor, 1, MPI_INT, target, tag, MPI_COMM_WORLD );
  else {
    for ( source = 0; source < nproc; source++ ) {
      if ( source != 0 )
        MPI_Recv( &pcolor, 1, MPI_INT, source, tag, MPI_COMM_WORLD, &status );
      switch ( pcolor ) {
        case 0:
          sprintf( color, "white" );
          break;
        case 1:
          sprintf( color, "red" );
          break;
        case 2:
          sprintf( color, "green" );
          break;
        default:
          sprintf( color, "Invalid color\n" );
          break;
      }

      printf( "proc %d has color %s\n", source, color );
    }
    printf( "\n\n" );
  }

  // Part Two

  pcolor = procID%3;

  switch ( pcolor ) {
    case 0:
      sprintf( color, "white" );
      break;
    case 1:
      sprintf( color, "red" );
      break;
    case 2:
      sprintf( color, "green" );
      break;
  }

  if ( procID != root )
    MPI_Send( color, 20, MPI_CHAR, root, tag, MPI_COMM_WORLD );
  else {
    printf( "proc %d has color %s\n", root, color );

    for ( source = 1; source < nproc; source++ )
    {
      MPI_Recv( color, 20, MPI_CHAR, source, tag, MPI_COMM_WORLD, &status );
      printf( "proc %d has color %s\n", source, color );
    }
  }

  free( colorArray );

  MPI_Finalize();

  return 0;

}
