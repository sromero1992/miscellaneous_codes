mpicc -o pcolor pcolor.c 
