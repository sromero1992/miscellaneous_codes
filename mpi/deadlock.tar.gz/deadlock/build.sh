mpicc -o deadlock deadlock.c
