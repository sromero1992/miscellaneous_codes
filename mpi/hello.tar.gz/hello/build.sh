mpicc -o hello hello.c
#mpirun -np 2 ./hello
