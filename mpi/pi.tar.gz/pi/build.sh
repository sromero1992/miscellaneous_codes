mpicc -o calcPi calcPi.c -std=c99
#mpirun -np 2 ./calcPi
